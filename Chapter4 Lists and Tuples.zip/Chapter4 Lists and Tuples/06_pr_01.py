a = input("Please enter first fruit: ")
b = input("Please enter second fruit: ")
c = input("Please enter third fruit: ")
d = input("Please enter fourth fruit: ")
e = input("Please enter fifth fruit: ")
f = input("Please enter sixth fruit: ")
g = input("Please enter seventh fruit: ")

list = [a, b, c, d, e, f, g] 
print(list)