a = int(input("Please enter mark 1: "))
b = int(input("Please enter mark 2: "))
c = int(input("Please enter mark 3: "))
d = int(input("Please enter mark 4: "))
e = int(input("Please enter mark 5: "))
f = int(input("Please enter mark 6: "))

list = [a, b, c, d, e, f]
list.sort()
print(list)