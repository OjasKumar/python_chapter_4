l1 = [1, 8, 7, 2, 21, 15]
print(l1)
# l1.sort() # It sorts the real list 
# l1.reverse() # Reverses the list
# l1.append(45) # adds 45 at the end of list
# l1.insert(2, 544) # inserts 544 at index 2
# l1.pop(2) # removes element at index 2
# l1.remove(21) # removes 21 from the list
print(l1)