# Creating a tuple using()
t = (1, 2, 4, 5)

# t1 = () # Empty tuple
# t1 = (1) # Wrong way to declare Tuple with single element
t1 = (1,) # Right way to declare Tuple with single element
print(t1)

# Printing the elements of a tuple
# print(t[0]) 

# Cannot update the value
# t[0] = 34 # Throws an error