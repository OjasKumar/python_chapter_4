tuple = (1, 2, 3, 4, 5)
tuple[0] = 45