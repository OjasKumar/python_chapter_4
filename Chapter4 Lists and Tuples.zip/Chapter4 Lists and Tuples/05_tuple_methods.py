t = (1, 2, 4, 5, 4, 1, 2, 1, 1) 

print(t.count(1))
print(t.index(5))