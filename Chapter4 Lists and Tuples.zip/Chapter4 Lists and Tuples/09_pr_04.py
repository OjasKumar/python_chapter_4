a = [1, 2, 3, 4]

print(a[0] + a[1] + a[2] + a[3])
print(sum(a))